'use server';
/**
 * @fileOverview An AI assistant that helps users draft personalized bulk order or customization requests for Nikki Cake Stands.
 *
 * - aiInquiryAssistant - A function that handles the inquiry drafting process.
 * - AiInquiryAssistantInput - The input type for the aiInquiryAssistant function.
 * - AiInquiryAssistantOutput - The return type for the aiInquiryAssistant function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiInquiryAssistantInputSchema = z.object({
  businessType: z.string().describe('The type of business (e.g., bakery, event planner, home baker, corporate gifting business, reseller).'),
  inquiryType: z.enum(['bulk_order', 'customization', 'partnership']).describe('The type of inquiry (bulk order, customization request, or potential partnership).'),
  productInterest: z.array(z.string()).optional().describe('Specific products or styles of cake stands the user is interested in (e.g., "Pink Bow Cake Stand", "Gold Ring Cake Stand", "Red Heart Cake Stand", "Happy Birthday Cake Stand").'),
  occasionDetails: z.string().optional().describe('Details about the occasion or event for which the cake stands are needed (e.g., "wedding reception", "baby shower", "corporate holiday party", "Valentine\'s Day collection").'),
  quantityNeeded: z.number().int().min(1).optional().describe('For bulk orders, the approximate quantity of cake stands needed.'),
  customizationDetails: z.string().optional().describe('For customization requests, specific requirements such as desired colors, branding, design elements, or themes.'),
  targetDate: z.string().optional().describe('The target date or timeframe by which the cake stands are needed (e.g., "by October 15th", "early next quarter", "before the holiday season").'),
  additionalNotes: z.string().optional().describe('Any other relevant information or specific questions the user has for Nikki Cake Stands.'),
});
export type AiInquiryAssistantInput = z.infer<typeof AiInquiryAssistantInputSchema>;

const AiInquiryAssistantOutputSchema = z.object({
  inquiryDraft: z.string().describe('A professionally drafted inquiry request to Nikki Cake Stands, personalized based on the provided details.'),
  keyDetailsExtracted: z.object({
    businessType: z.string().describe('The type of business identified in the input.'),
    inquiryType: z.enum(['bulk_order', 'customization', 'partnership']).describe('The type of inquiry identified.'),
    occasion: z.string().optional().describe('The main occasion or event mentioned, if any.'),
    productsOfInterest: z.array(z.string()).optional().describe('A list of specific products or styles of cake stands the user is interested in, if any.'),
    customizationRequested: z.boolean().describe('True if customization details were provided, false otherwise.'),
    quantitySpecified: z.number().int().min(1).optional().describe('The quantity specified for a bulk order, if any.'),
    targetDateSpecified: z.string().optional().describe('The target date or timeframe specified, if any.'),
  }).describe('Structured summary of key details extracted from the user input for internal processing or confirmation.'),
});
export type AiInquiryAssistantOutput = z.infer<typeof AiInquiryAssistantOutputSchema>;

export async function aiInquiryAssistant(input: AiInquiryAssistantInput): Promise<AiInquiryAssistantOutput> {
  return aiInquiryAssistantFlow(input);
}

const inquiryPrompt = ai.definePrompt({
  name: 'inquiryAssistantPrompt',
  input: {schema: AiInquiryAssistantInputSchema},
  output: {schema: AiInquiryAssistantOutputSchema},
  prompt: `You are an AI assistant helping a business client (e.g., bakery owner, event planner) draft a professional and detailed inquiry to Nikki Cake Stands.
Nikki Cake Stands creates elegant, occasion-based cake stands for businesses.

Based on the following information, draft a comprehensive and polite inquiry request in the 'inquiryDraft' field. The inquiry should be structured clearly, detailing the client's business type, their specific needs (bulk order, customization, or partnership), product interests, occasion details, desired quantities (if applicable), customization requirements (if applicable), and target timelines.
Ensure the tone is professional, appreciative, and clear. Avoid mentioning "MOQ" directly; instead, frame it as "order details and pricing" if necessary.

Also, extract the key details provided by the user into the 'keyDetailsExtracted' JSON object, ensuring it strictly adheres to the provided schema.

---
Client Business Type: {{{businessType}}}
Inquiry Type: {{{inquiryType}}}
{{#if productInterest}}
Product(s) of Interest: {{#each productInterest}}- {{this}}
{{/each}}{{/if}}
{{#if occasionDetails}}
Occasion/Event Details: {{{occasionDetails}}}
{{/if}}
{{#if quantityNeeded}}
Approximate Quantity Needed: {{{quantityNeeded}}} units
{{/if}}
{{#if customizationDetails}}
Customization Requirements: {{{customizationDetails}}}
{{/if}}
{{#if targetDate}}
Target Date/Timeframe: {{{targetDate}}}
{{/if}}
{{#if additionalNotes}}
Additional Notes: {{{additionalNotes}}}
{{/if}}
---

Draft the inquiry starting with a polite greeting to Nikki Cake Stands.

Example structure for inquiryDraft:
Dear Nikki Cake Stands Team,

[Introduction about client's business and purpose of inquiry]

[Details about product interest, occasion, quantity, customization]

[Request for pricing, lead times, and next steps]

[Closing]
`,
});

const aiInquiryAssistantFlow = ai.defineFlow(
  {
    name: 'aiInquiryAssistantFlow',
    inputSchema: AiInquiryAssistantInputSchema,
    outputSchema: AiInquiryAssistantOutputSchema,
  },
  async (input) => {
    const {output} = await inquiryPrompt(input);
    if (!output) {
      throw new Error('Failed to generate inquiry draft.');
    }
    return output;
  }
);
