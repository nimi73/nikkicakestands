
"use client"

import { Navbar } from "@/components/ui/navbar"
import { Hero } from "@/components/sections/Hero"
import { ProductShowcase } from "@/components/sections/ProductShowcase"
import { B2BSection } from "@/components/sections/B2BSection"
import { InquiryAssistant } from "@/components/sections/InquiryAssistant"
import { Platforms } from "@/components/sections/Platforms"
import { FAQSection } from "@/components/sections/FAQSection"
import { Footer } from "@/components/sections/Footer"
import { Toaster } from "@/components/ui/toaster"
import Image from "next/image"
import { PlaceHolderImages } from "@/lib/placeholder-images"
import { emailLink, whatsappLink } from "@/lib/contact"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <Hero />
      
      {/* Brand Intro Section - Applied bg-secondary for Lavender effect */}
      <section id="about" className="py-24 bg-secondary">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2 relative aspect-square w-full max-w-md mx-auto">
              <div className="absolute inset-0 bg-accent rounded-full -z-10 blur-3xl opacity-40"></div>
              <Image 
                src={PlaceHolderImages.find(i => i.id === "gallery-1")?.imageUrl || ""}
                alt="Styled Celebration"
                fill
                className="object-cover rounded-3xl shadow-xl"
                data-ai-hint="elegant bakery"
              />
            </div>
            <div className="lg:w-1/2 space-y-6">
              <span className="font-script text-2xl text-primary block">About the Brand</span>
              <h2 className="font-headline text-4xl lg:text-5xl font-bold">Premium Display Solutions for Celebration Businesses</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Nikki Cake Stands creates elegant, occasion-ready cake stands designed for bakeries, cake businesses, event planners, and celebration brands. Our products help transform cake presentation into a premium visual experience while also offering practical bulk-order solutions for business use.
              </p>
              <div className="grid grid-cols-2 gap-8 pt-6">
                <div className="p-4 rounded-2xl bg-white/50 backdrop-blur-sm shadow-sm border border-white/20">
                  <h4 className="font-headline text-2xl text-primary mb-1">Quality</h4>
                  <p className="text-sm text-muted-foreground">Premium materials designed for repeat professional use.</p>
                </div>
                <div className="p-4 rounded-2xl bg-white/50 backdrop-blur-sm shadow-sm border border-white/20">
                  <h4 className="font-headline text-2xl text-primary mb-1">Impact</h4>
                  <p className="text-sm text-muted-foreground">Elevate your brand aesthetic and customer perception.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <ProductShowcase />
      <B2BSection />
      
      {/* Visual Inspiration Gallery */}
      <section className="py-24 bg-secondary">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <span className="font-script text-xl text-primary block mb-2">Inspiration</span>
            <h2 className="font-headline text-4xl font-bold">Styled for Celebrations</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {["gallery-1", "gallery-2", "gallery-3"].map((id, idx) => (
              <div key={id} className={`relative overflow-hidden rounded-3xl group ${idx === 1 ? 'md:translate-y-12' : ''}`}>
                <div className="aspect-[4/5] relative">
                  <Image 
                    src={PlaceHolderImages.find(i => i.id === id)?.imageUrl || ""}
                    alt={`Styled Gallery ${idx + 1}`}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                    data-ai-hint="celebration cake"
                  />
                  <div className="absolute inset-0 bg-primary/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <InquiryAssistant />
      <Platforms />
      <FAQSection />
      
      {/* Final CTA */}
      <section className="py-24 bg-primary text-white overflow-hidden relative">
        <div className="container mx-auto px-6 text-center z-10 relative">
          <span className="font-script text-2xl opacity-90 block mb-4">Let&apos;s Connect</span>
          <h2 className="font-headline text-4xl lg:text-5xl font-bold mb-8 max-w-3xl mx-auto">
            Ready to Create Beautiful Displays for Your Business?
          </h2>
          <div className="flex flex-wrap justify-center gap-4">
            <a 
              href={whatsappLink("Hi Nikki Cake Stands, I am interested in your cake stands for my business. Please share your catalog, pricing and order details.")} 
              className="bg-white text-primary px-10 py-4 rounded-full font-bold hover:bg-white/90 transition-all shadow-xl flex items-center gap-2"
            >
              WhatsApp: 9870511005
            </a>
            <a 
              href={emailLink("Nikki Cake Stands business inquiry")} 
              className="bg-transparent border-2 border-white/30 text-white px-10 py-4 rounded-full font-bold hover:bg-white/10 transition-all flex items-center gap-2"
            >
              Email Sales Team
            </a>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute -top-1/2 -left-1/4 w-[600px] h-[600px] bg-white/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-1/2 -right-1/4 w-[600px] h-[600px] bg-black/5 rounded-full blur-3xl" />
      </section>

      <Footer />
      <Toaster />
    </main>
  )
}
