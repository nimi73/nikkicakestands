import Link from "next/link"
import { CONTACT } from "@/lib/contact"

export default function TermsPage() {
  return (
    <main className="min-h-screen bg-background px-6 py-16">
      <div className="mx-auto max-w-3xl rounded-3xl border bg-white p-8 shadow-sm">
        <Link href="/" className="text-sm text-primary hover:underline">← Back to Home</Link>
        <h1 className="mt-6 font-headline text-4xl font-bold text-primary">Terms of Service</h1>
        <p className="mt-4 text-muted-foreground">Last updated: June 2026</p>
        <div className="mt-8 space-y-5 text-sm leading-7 text-muted-foreground">
          <p>The information on this website is provided for product discovery and business inquiry purposes. Product availability, pricing, customization, and order terms are shared directly after inquiry.</p>
          <p>Images and descriptions are for representation of Nikki Cake Stands products. Final product details, finish, packaging, and order quantity may vary based on confirmed order specifications.</p>
          <p>All brand assets, product designs, images, and website content belong to Nikki Cake Stands unless otherwise stated.</p>
          <p>For order terms, catalog requests, or support, contact us at <a className="text-primary hover:underline" href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a>.</p>
        </div>
      </div>
    </main>
  )
}
