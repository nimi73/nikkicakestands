import Link from "next/link"
import { CONTACT } from "@/lib/contact"

export default function PrivacyPolicyPage() {
  return (
    <main className="min-h-screen bg-background px-6 py-16">
      <div className="mx-auto max-w-3xl rounded-3xl border bg-white p-8 shadow-sm">
        <Link href="/" className="text-sm text-primary hover:underline">← Back to Home</Link>
        <h1 className="mt-6 font-headline text-4xl font-bold text-primary">Privacy Policy</h1>
        <p className="mt-4 text-muted-foreground">Last updated: June 2026</p>
        <div className="mt-8 space-y-5 text-sm leading-7 text-muted-foreground">
          <p>Nikki Cake Stands may collect basic inquiry details such as your name, business type, phone number, email address, product interest, quantity requirement, and message when you contact us through WhatsApp, email, or the website.</p>
          <p>We use this information only to respond to product inquiries, share catalog/pricing details, process business communication, and improve our customer service.</p>
          <p>We do not sell your personal information. Your information may be shared only with service providers required to support order processing, delivery, or business communication.</p>
          <p>For privacy-related requests, contact us at <a className="text-primary hover:underline" href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a>.</p>
        </div>
      </div>
    </main>
  )
}
