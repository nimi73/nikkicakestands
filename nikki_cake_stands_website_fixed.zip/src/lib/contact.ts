export const CONTACT = {
  whatsappNumberDisplay: '9870511005',
  whatsappNumberInternational: '919870511005',
  email: 'sales@nikkicakestands.com',
  instagramUrl: 'https://www.instagram.com/nikkicakestands?igsh=cTk2MWZlNXcyNncy',
}

export function whatsappLink(message: string) {
  return `https://wa.me/${CONTACT.whatsappNumberInternational}?text=${encodeURIComponent(message)}`
}

export function emailLink(subject?: string) {
  return `mailto:${CONTACT.email}${subject ? `?subject=${encodeURIComponent(subject)}` : ''}`
}
