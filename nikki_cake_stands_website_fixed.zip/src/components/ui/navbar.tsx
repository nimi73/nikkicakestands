"use client"

import * as React from "react"
import Link from "next/link"
import Image from "next/image"
import { MessageCircle, Mail, Menu } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet"
import { PlaceHolderImages } from "@/lib/placeholder-images"
import { CONTACT, emailLink, whatsappLink } from "@/lib/contact"

const navLinks = [
  { name: "About", href: "#about" },
  { name: "Products", href: "#products" },
  { name: "Bulk Orders", href: "#bulk" },
  { name: "Customization", href: "#custom" },
  { name: "Platforms", href: "#platforms" },
  { name: "FAQ", href: "#faq" },
  { name: "Contact", href: "#contact" },
]

const whatsappMessage =
  "Hi Nikki Cake Stands, I am interested in your cake stands for my business. Please share your catalog, pricing and order details."

export function Navbar() {
  const [scrolled, setScrolled] = React.useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false)
  const logo = PlaceHolderImages.find(img => img.id === "brand-logo")

  React.useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
      scrolled ? "bg-background/90 backdrop-blur-md border-b py-3 shadow-sm" : "bg-transparent py-6"
    )}>
      <div className="container mx-auto px-6 flex items-center justify-between gap-4">
        <Link href="/" className="relative h-20 w-48 sm:h-24 sm:w-64 lg:w-80 shrink-0" aria-label="Nikki Cake Stands home">
          {logo?.imageUrl ? (
            <Image 
              src={logo.imageUrl} 
              alt="Nikki Cake Stands Logo" 
              fill 
              className="object-contain object-left"
              priority
            />
          ) : (
            <div className="flex flex-col items-start">
              <span className="font-headline text-3xl font-bold tracking-tight text-primary">Nikki</span>
              <span className="font-script text-lg -mt-2 opacity-80">Cake Stands</span>
            </div>
          )}
        </Link>

        <nav className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link 
              key={link.name} 
              href={link.href} 
              className="text-sm font-medium hover:text-primary transition-colors duration-200"
            >
              {link.name}
            </Link>
          ))}
        </nav>

        <div className="hidden sm:flex items-center gap-4">
          <Button variant="outline" className="border-primary text-primary hover:bg-primary/10 rounded-full" asChild>
            <a href={emailLink("Nikki Cake Stands business inquiry")}>
              <Mail className="mr-2 h-4 w-4" />
              Email Sales
            </a>
          </Button>
          <Button className="bg-primary text-white hover:bg-primary/90 rounded-full shadow-lg" asChild>
            <a href={whatsappLink(whatsappMessage)} target="_blank" rel="noopener noreferrer">
              <MessageCircle className="mr-2 h-4 w-4" />
              WhatsApp
            </a>
          </Button>
        </div>

        <div className="flex items-center gap-2 sm:hidden">
          <Button size="icon" className="bg-primary text-white hover:bg-primary/90 rounded-full shadow-lg" asChild>
            <a href={whatsappLink(whatsappMessage)} target="_blank" rel="noopener noreferrer" aria-label={`WhatsApp Nikki Cake Stands on ${CONTACT.whatsappNumberDisplay}`}>
              <MessageCircle className="h-4 w-4" />
            </a>
          </Button>
        </div>

        <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="lg:hidden rounded-full border-primary/30" aria-label="Open menu">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] sm:w-[360px]">
            <SheetHeader>
              <SheetTitle className="font-headline text-left text-2xl text-primary">Nikki Cake Stands</SheetTitle>
            </SheetHeader>
            <nav className="mt-8 flex flex-col gap-4">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="rounded-2xl px-4 py-3 text-base font-medium hover:bg-secondary hover:text-primary transition-colors"
                >
                  {link.name}
                </Link>
              ))}
            </nav>
            <div className="mt-8 flex flex-col gap-3">
              <Button className="bg-primary text-white rounded-full" asChild>
                <a href={whatsappLink(whatsappMessage)} target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="mr-2 h-4 w-4" />
                  WhatsApp Us
                </a>
              </Button>
              <Button variant="outline" className="border-primary text-primary rounded-full" asChild>
                <a href={emailLink("Nikki Cake Stands business inquiry")}>
                  <Mail className="mr-2 h-4 w-4" />
                  {CONTACT.email}
                </a>
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  )
}
