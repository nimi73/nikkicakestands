
"use client"

import Image from "next/image"
import { PlaceHolderImages } from "@/lib/placeholder-images"

export function Hero() {
  const heroImg = PlaceHolderImages.find(img => img.id === "hero-cake-stand")
  const isVideo = heroImg?.imageUrl.endsWith('.mp4')

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-background">
      <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div className="flex flex-col space-y-8 animate-fade-in text-center lg:text-left z-10">
          <div>
            <span className="font-script text-2xl text-primary block mb-2">Crafted for Celebrations</span>
            <h1 className="font-headline text-5xl md:text-6xl lg:text-7xl leading-tight text-foreground font-semibold">
              Elegant Cake Stands for <span className="text-primary italic">Bakeries</span> & Events
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto lg:mx-0">
              Premium cake stand solutions designed for bakeries, event businesses, celebration brands, and gifting occasions. Elevate your display with our boutique collection.
            </p>
          </div>

          <div className="pt-8 border-t border-primary/20">
            <p className="text-sm text-muted-foreground">
              Available on: <span className="font-medium text-foreground">Blinkit • Zepto • Swiggy Instamart • Amazon.in</span>
            </p>
          </div>
        </div>

        <div className="relative h-[500px] lg:h-[700px] w-full animate-fade-in [animation-delay:200ms]">
          <div className="absolute inset-0 bg-accent rounded-3xl -rotate-3 transition-transform duration-500 hover:rotate-0 opacity-40"></div>
          <div className="absolute inset-0 z-10 overflow-hidden rounded-3xl shadow-2xl border-4 border-white bg-white">
            {isVideo ? (
              <video 
                src={heroImg?.imageUrl} 
                autoPlay 
                loop 
                muted 
                playsInline 
                className="w-full h-full object-cover"
              />
            ) : (
              <Image 
                src={heroImg?.imageUrl || ""} 
                alt="Premium Cake Stand Display" 
                fill
                className="object-cover"
                priority
                data-ai-hint="premium cake stand"
              />
            )}
            <div className="absolute bottom-6 left-6 right-6 bg-white/90 backdrop-blur-md p-6 rounded-2xl border border-white/50">
              <span className="text-xs uppercase tracking-widest text-primary font-bold mb-1 block">Featured Style</span>
              <p className="font-headline text-xl text-foreground font-medium">Antique Gold Edition</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative background elements */}
      <div className="absolute top-1/4 -right-20 w-[500px] h-[500px] bg-accent/20 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-1/4 -left-20 w-[500px] h-[500px] bg-primary/5 rounded-full blur-3xl -z-10"></div>
    </section>
  )
}
