"use client"

import Image from "next/image"
import { PlaceHolderImages } from "@/lib/placeholder-images"

export function Platforms() {
  const logos = [
    { id: "platform-blinkit", name: "Blinkit" },
    { id: "platform-zepto", name: "Zepto" },
    { id: "platform-swiggy", name: "Swiggy Instamart" },
    { id: "platform-amazon", name: "Amazon.in" }
  ]

  return (
    <section id="platforms" className="py-20 bg-background border-b">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <span className="font-script text-xl text-primary block mb-2">Retail Presence</span>
          <h2 className="font-headline text-3xl font-bold mb-4">Available Across Leading Platforms</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            While we focus on B2B excellence, our retail presence across India's leading quick-commerce platforms ensures brand trust and individual accessibility.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16 opacity-70 grayscale hover:grayscale-0 transition-all duration-500">
          {logos.map((logo) => {
            const img = PlaceHolderImages.find(i => i.id === logo.id)
            return (
              <div key={logo.id} className="relative h-12 w-40">
                <Image 
                  src={img?.imageUrl || ""} 
                  alt={logo.name} 
                  fill
                  className="object-contain"
                />
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}