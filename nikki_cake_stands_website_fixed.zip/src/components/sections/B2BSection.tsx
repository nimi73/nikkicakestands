"use client"

import { Button } from "@/components/ui/button"
import { Building2, Package, RefreshCw, Palette, Users, TrendingUp } from "lucide-react"
import { emailLink, whatsappLink } from "@/lib/contact"

const features = [
  {
    icon: Building2,
    title: "Bakery Chains",
    desc: "Standardized premium display solutions for multi-outlet brands."
  },
  {
    icon: Package,
    title: "Bulk Ready",
    desc: "Optimized logistics and volume pricing for large-scale requirements."
  },
  {
    icon: RefreshCw,
    title: "Repeat Supply",
    desc: "Consistent inventory management for seasonal and ongoing needs."
  },
  {
    icon: Palette,
    title: "Customization",
    desc: "Private label and theme-specific modifications for your brand."
  },
  {
    icon: Users,
    title: "Event Planners",
    desc: "Boutique designs that elevate event aesthetics and cake presentation."
  },
  {
    icon: TrendingUp,
    title: "Gifting Brands",
    desc: "Unique packaging companions for premium celebration hampers."
  }
]

const bulkWhatsAppMessage =
  "Hi Nikki Cake Stands, I am interested in bulk ordering cake stands for my business. Please share your catalog, pricing, available designs and order details."

export function B2BSection() {
  return (
    <section id="bulk" className="py-24 bg-background border-y">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <span className="font-script text-xl text-primary block mb-2">Business Solutions</span>
            <h2 className="font-headline text-4xl lg:text-5xl font-bold mb-6">Built for Bulk Orders & Business Growth</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Whether you run a high-volume bakery, manage a national cake chain, or organize premium corporate events, Nikki Cake Stands provides the scale and quality your business demands.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3">
                <div className="h-2 w-2 rounded-full bg-primary" />
                <span className="font-medium">Tailored pricing for high-volume inquiries</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-2 w-2 rounded-full bg-primary" />
                <span className="font-medium">Reliable delivery schedules for festive seasons</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-2 w-2 rounded-full bg-primary" />
                <span className="font-medium">Direct relationship management for repeat clients</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-primary text-white rounded-full px-8" asChild>
                <a href={whatsappLink(bulkWhatsAppMessage)} target="_blank" rel="noopener noreferrer">WhatsApp for Bulk</a>
              </Button>
              <Button size="lg" variant="outline" className="border-primary text-primary rounded-full px-8" asChild>
                <a href={emailLink("Nikki Cake Stands catalog request")}>Request Catalog</a>
              </Button>
            </div>
            <p className="mt-4 text-xs text-muted-foreground italic">
              * MOQ and volume details provided privately upon inquiry.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {features.map((feature) => (
              <div key={feature.title} className="p-6 rounded-3xl bg-secondary/20 hover:bg-secondary/40 transition-colors border border-transparent hover:border-primary/10">
                <feature.icon className="h-8 w-8 text-primary mb-4" />
                <h3 className="font-headline text-xl mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
