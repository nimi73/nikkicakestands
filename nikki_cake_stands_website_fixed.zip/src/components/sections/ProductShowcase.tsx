"use client"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { PlaceHolderImages } from "@/lib/placeholder-images"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { whatsappLink } from "@/lib/contact"

const products = [
  {
    id: "product-pink-bow",
    name: "Pink Bow Cake Stand",
    tagline: "Feminine & Soft",
    description: "Soft pink occasion stand with bow-inspired structure, perfect for birthdays and baby showers.",
    occasions: ["Birthdays", "Baby Showers", "Girls Parties"],
    imageKey: "product-pink-bow"
  },
  {
    id: "product-gold-ring",
    name: "Gold Ring Cake Stand",
    tagline: "Premium & Luxe",
    description: "Elegant gold-toned stand with ring-inspired side structure, suited for high-end styling.",
    occasions: ["Engagements", "Weddings", "Luxury Events"],
    imageKey: "product-gold-ring"
  },
  {
    id: "product-red-heart",
    name: "Red Heart Cake Stand",
    tagline: "Romantic & Bold",
    description: "Romantic heart-shaped support design ideal for anniversaries and love-themed celebrations.",
    occasions: ["Anniversaries", "Valentines", "Proposals"],
    imageKey: "product-red-heart"
  },
  {
    id: "product-birthday",
    name: "Happy Birthday Stand",
    tagline: "Cheerful & Festive",
    description: "Colourful celebration stand with front panel design, perfect for bright festive cake displays.",
    occasions: ["Kids Birthdays", "Festive Gifting", "Milestones"],
    imageKey: "product-birthday"
  }
]

export function ProductShowcase() {
  return (
    <section id="products" className="py-24 bg-secondary/50">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="font-script text-xl text-primary block mb-2">The Collection</span>
          <h2 className="font-headline text-4xl font-bold mb-4">Occasion-Based Displays</h2>
          <p className="text-muted-foreground">
            Our specialized product lines are designed to complement specific celebration themes, adding a layer of professional elegance to every cake.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => {
            const img = PlaceHolderImages.find(i => i.id === product.imageKey)
            return (
              <Card key={product.id} className="group overflow-hidden border-none shadow-sm hover:shadow-2xl transition-all duration-500 rounded-3xl bg-white">
                <CardHeader className="p-0">
                  <div className="relative aspect-square overflow-hidden">
                    <Image 
                      src={img?.imageUrl || ""} 
                      alt={product.name}
                      fill
                      className="object-cover transition-transform duration-700 group-hover:scale-110"
                      data-ai-hint={img?.imageHint}
                    />
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-secondary/90 backdrop-blur-sm text-primary border-none font-medium">
                        {product.tagline}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <CardTitle className="font-headline text-xl mb-2">{product.name}</CardTitle>
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {product.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {product.occasions.map(occ => (
                      <span key={occ} className="text-[10px] uppercase tracking-widest font-bold text-primary/60">
                        • {occ}
                      </span>
                    ))}
                  </div>
                </CardContent>
                <CardFooter className="p-6 pt-0 flex flex-col gap-2">
                  <Button variant="outline" className="w-full border-primary/20 hover:border-primary text-primary text-xs rounded-full h-9" asChild>
                    <a href={whatsappLink(`Hi Nikki Cake Stands, I am interested in bulk enquiry for ${product.name}. Please share catalog, pricing, available quantity and order details.`)} target="_blank" rel="noopener noreferrer">Enquire for Bulk</a>
                  </Button>
                </CardFooter>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}