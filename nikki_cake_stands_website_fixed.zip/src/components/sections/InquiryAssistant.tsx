"use client"

import * as React from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { Sparkles, Loader2, Copy, Check, MessageSquare } from "lucide-react"
import { aiInquiryAssistant } from "@/ai/flows/ai-inquiry-assistant"
import { Button } from "@/components/ui/button"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { whatsappLink } from "@/lib/contact"

const formSchema = z.object({
  businessType: z.string().min(2, "Please specify your business type"),
  inquiryType: z.enum(["bulk_order", "customization", "partnership"]),
  productInterest: z.string().optional(),
  quantityNeeded: z.string().optional(),
  targetDate: z.string().optional(),
  additionalNotes: z.string().optional(),
})

export function InquiryAssistant() {
  const [isGenerating, setIsGenerating] = React.useState(false)
  const [draft, setDraft] = React.useState<string | null>(null)
  const [copied, setCopied] = React.useState(false)
  const { toast } = useToast()

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      businessType: "",
      inquiryType: "bulk_order",
      productInterest: "",
      quantityNeeded: "",
      targetDate: "",
      additionalNotes: "",
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsGenerating(true)
    try {
      const result = await aiInquiryAssistant({
        businessType: values.businessType,
        inquiryType: values.inquiryType as any,
        productInterest: values.productInterest ? [values.productInterest] : [],
        quantityNeeded: values.quantityNeeded ? parseInt(values.quantityNeeded) : undefined,
        targetDate: values.targetDate,
        additionalNotes: values.additionalNotes,
      })
      setDraft(result.inquiryDraft)
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error generating draft",
        description: "Please try again later or contact us directly.",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const copyToClipboard = () => {
    if (draft) {
      navigator.clipboard.writeText(draft)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
      toast({
        title: "Draft copied",
        description: "You can now paste this into your email or WhatsApp message.",
      })
    }
  }

  return (
    <section id="custom" className="py-24 bg-secondary/50">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <span className="font-script text-xl text-primary block mb-2">Smart Inquiry</span>
            <h2 className="font-headline text-4xl font-bold mb-4">Intelligent Inquiry Assistant</h2>
            <p className="text-muted-foreground">
              Let our AI help you draft a professional customization or bulk order request tailored to your business needs.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            <Card className="border-border/50 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  Your Requirements
                </CardTitle>
                <CardDescription>Tell us about your celebration needs</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="businessType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Business Type</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Luxury Bakery, Event Planner" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="inquiryType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Inquiry Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select inquiry type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="bulk_order">Bulk Order</SelectItem>
                              <SelectItem value="customization">Customization Request</SelectItem>
                              <SelectItem value="partnership">Potential Partnership</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="quantityNeeded"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Approx. Quantity</FormLabel>
                            <FormControl>
                              <Input type="number" placeholder="50" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="targetDate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Target Date</FormLabel>
                            <FormControl>
                              <Input placeholder="Next month" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={form.control}
                      name="additionalNotes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Specific Details</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Mention specific colors, branding or celebration themes..." 
                              className="min-h-[100px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="submit" 
                      className="w-full bg-primary text-white hover:bg-primary/90"
                      disabled={isGenerating}
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Crafting Draft...
                        </>
                      ) : (
                        <>
                          <Sparkles className="mr-2 h-4 w-4" />
                          Generate Professional Inquiry
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <div className="space-y-6">
              {draft ? (
                <Card className="border-primary/20 shadow-xl bg-white/50 backdrop-blur-sm animate-fade-in">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Generated Inquiry Draft</CardTitle>
                    <Button variant="ghost" size="icon" onClick={copyToClipboard}>
                      {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-background rounded-lg p-4 text-sm leading-relaxed whitespace-pre-wrap border max-h-[400px] overflow-y-auto">
                      {draft}
                    </div>
                    <div className="mt-6 flex flex-col gap-3">
                      <Button className="w-full bg-primary text-white" asChild>
                        <a href={whatsappLink(draft)} target="_blank" rel="noopener noreferrer">
                          <MessageSquare className="mr-2 h-4 w-4" />
                          Send to WhatsApp
                        </a>
                      </Button>
                      <p className="text-[10px] text-center text-muted-foreground italic">
                        Nikki Cake Stands typically responds within 4-6 business hours.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="h-full flex flex-col items-center justify-center p-12 text-center border-2 border-dashed rounded-3xl opacity-50">
                  <MessageSquare className="h-12 w-12 text-primary/30 mb-4" />
                  <p className="text-muted-foreground font-headline italic">
                    "Your professional draft will appear here..."
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}