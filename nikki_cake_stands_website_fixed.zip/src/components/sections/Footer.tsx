"use client"

import Link from "next/link"
import Image from "next/image"
import { MessageCircle, Mail, MapPin, Instagram } from "lucide-react"
import { PlaceHolderImages } from "@/lib/placeholder-images"
import { CONTACT, emailLink, whatsappLink } from "@/lib/contact"

const footerWhatsAppMessage =
  "Hi Nikki Cake Stands, I am interested in your cake stands for my business. Please share your catalog, pricing and order details."

export function Footer() {
  const logo = PlaceHolderImages.find(img => img.id === "brand-logo")

  return (
    <footer id="contact" className="bg-[#1A1816] text-white pt-24 pb-12">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <Link href="/" className="relative h-24 w-80 block" aria-label="Nikki Cake Stands home">
              {logo?.imageUrl ? (
                <Image 
                  src={logo.imageUrl} 
                  alt="Nikki Cake Stands Logo" 
                  fill 
                  className="object-contain object-left"
                />
              ) : (
                <div className="flex flex-col items-start">
                  <span className="font-headline text-3xl font-bold tracking-tight text-primary">Nikki</span>
                  <span className="font-script text-lg -mt-2 opacity-80">Cake Stands</span>
                </div>
              )}
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed max-w-xs">
              Elegant, occasion-based cake stands designed for modern Indian bakeries, gifting brands, and celebration businesses.
            </p>
            <div className="flex gap-4">
              <a
                href={CONTACT.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Visit Nikki Cake Stands on Instagram"
                className="h-10 w-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-primary/20 transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-headline text-xl mb-6">Quick Links</h4>
            <ul className="space-y-4">
              <li><Link href="#about" className="text-gray-400 hover:text-primary transition-colors text-sm">About Nikki</Link></li>
              <li><Link href="#products" className="text-gray-400 hover:text-primary transition-colors text-sm">Collection</Link></li>
              <li><Link href="#bulk" className="text-gray-400 hover:text-primary transition-colors text-sm">Bulk Inquiries</Link></li>
              <li><Link href="#custom" className="text-gray-400 hover:text-primary transition-colors text-sm">Custom Projects</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-headline text-xl mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MessageCircle className="h-5 w-5 text-primary shrink-0" />
                <a href={whatsappLink(footerWhatsAppMessage)} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-primary transition-colors text-sm">+91 {CONTACT.whatsappNumberDisplay}</a>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-primary shrink-0" />
                <a href={emailLink("Nikki Cake Stands business inquiry")} className="text-gray-400 hover:text-primary transition-colors text-sm">{CONTACT.email}</a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-primary shrink-0" />
                <span className="text-gray-400 text-sm">Mumbai, Maharashtra, India</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-headline text-xl mb-6">Retail Presence</h4>
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-white/5 rounded-full text-xs text-gray-300">Blinkit</span>
              <span className="px-3 py-1 bg-white/5 rounded-full text-xs text-gray-300">Zepto</span>
              <span className="px-3 py-1 bg-white/5 rounded-full text-xs text-gray-300">Swiggy</span>
              <span className="px-3 py-1 bg-white/5 rounded-full text-xs text-gray-300">Amazon</span>
            </div>
            <p className="mt-6 text-[10px] text-gray-500 italic">
              Nikki Cake Stands is a registered brand. All designs are protected by copyright.
            </p>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-500">
          <p>© 2026 Nikki Cake Stands. All Rights Reserved.</p>
          <div className="flex gap-6">
            <Link href="/privacy-policy" className="hover:text-primary transition-colors">Privacy Policy</Link>
            <Link href="/terms" className="hover:text-primary transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
