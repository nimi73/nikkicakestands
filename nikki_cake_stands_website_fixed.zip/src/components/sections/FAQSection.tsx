"use client"

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

const faqs = [
  {
    q: "Do you take bulk orders for bakeries?",
    a: "Yes, we specialize in serving bakeries, cake chains, and celebration brands with high-volume requirements. We offer standardized pricing and reliable supply for business clients."
  },
  {
    q: "Can I request customized designs or branding?",
    a: "Absolutely. We support customization for private label requests, business branding, and occasion-specific theme stand solutions. Contact us to discuss your project."
  },
  {
    q: "How can I get business pricing and catalogs?",
    a: "Please connect with us via WhatsApp (9870511005) or email (sales@nikkicakestands.com). We will share our professional catalog and volume-based pricing structures."
  },
  {
    q: "Do you mention MOQ on the website?",
    a: "No, we keep our Minimum Order Quantities (MOQ) inquiry-based to provide the best possible flexibility for different business sizes and customization needs."
  },
  {
    q: "Is shipping available nationwide for bulk orders?",
    a: "Yes, we provide specialized shipping and logistics support for bulk orders across India, ensuring safe and timely delivery for your business operations."
  },
  {
    q: "Are your products available for individual buyers?",
    a: "Yes, selected collections are available for quick delivery on platforms like Blinkit, Zepto, Swiggy Instamart, and Amazon.in."
  }
]

export function FAQSection() {
  return (
    <section id="faq" className="py-24 bg-background">
      <div className="container mx-auto px-6 max-w-3xl">
        <div className="text-center mb-16">
          <span className="font-script text-xl text-primary block mb-2">Information</span>
          <h2 className="font-headline text-4xl font-bold mb-4">Frequently Asked Questions</h2>
        </div>

        <Accordion type="single" collapsible className="w-full space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`} className="border rounded-2xl px-6 bg-secondary/10">
              <AccordionTrigger className="hover:no-underline font-headline text-lg py-6">{faq.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-6 leading-relaxed">
                {faq.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  )
}