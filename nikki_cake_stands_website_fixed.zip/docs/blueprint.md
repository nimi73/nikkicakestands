# **App Name**: Nikki Cake Stands

## Core Features:

- Intelligent B2B Inquiry Tool: A generative AI-powered tool that helps business buyers draft personalized customization requests or bulk order inquiries for specific celebration themes.
- Curated Product Portfolio: An editorial-style showcase featuring specialized categories like Pink Bow, Gold Ring, and Red Heart cake stands with elegant hover transitions.
- Platform Presence Portal: Dynamic integration of B2C visibility markers for Blinkit, Zepto, and Swiggy Instamart to build brand trust with corporate partners.
- Customization Project Request: A structured multi-step inquiry flow specifically for private label and custom brand-aligned stand solutions.
- Direct Business Connect: Sticky primary call-to-action for WhatsApp (9870511005) and secondary email integration for official B2B communications.
- Contextual FAQ Module: An interactive accordion system addressing key B2B concerns like business logistics and customization options.

## Style Guidelines:

- Primary color: Antique Gold (#A8894F) for a premium, boutique celebration feel. Background: Warm Ivory (#FAF8F3) to provide a soft, light, and airy canvas. Accent: Soft Blush Pink (#F7DDE8) used sparingly for high-end femininity.
- Headline font: 'Playfair Display' (Serif) for a high-end, editorial elegance. Body font: 'Inter' (Sans-serif) for professional readability. Note: Subtle decorative handwritten accents are recommended for labels like 'Crafted for Celebrations'.
- Minimalist, thin-line gold icons that reflect celebratory elements such as cakes, gift boxes, and festive rings.
- A sophisticated single-page editorial layout featuring a full-screen product-focused hero and wide white space to maintain a premium feel.
- Elegant soft-fade transitions and subtle scale effects on product cards to emphasize quality and refined craftsmanship.